<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'bond');

/** Имя пользователя MySQL */
define('DB_USER', 'root');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', '');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '?k A;<>B{K/%ifdzxHzuW[3,MDWt-68oC(0!3Oza{<wY;.76Z,-H<.#%xTjA#*&W');
define('SECURE_AUTH_KEY',  'MHt1f}*Qxzo{QrX!=]Y4Z/r$?&3v QuPWQxE?Rje!>V.1eR2r7*8o+aVEg>^o{T{');
define('LOGGED_IN_KEY',    '<A:!V3d|A}o@4a~/+{qM4%B;=i=Ri?]^.x tCFwwyW]:} :pv2q[xP1n4,1E,(BJ');
define('NONCE_KEY',        '8&(xYA#`2 Z99aG@$y:@0+dy)]+$y#0#+O>AH:l[F0hLPGO kw`fU{KEZSx+8{Fd');
define('AUTH_SALT',        'AM~p-9+u^]L1ECv4RuS|C8crYfmB,Ck|Y>2Ng/6kUE4QF%#rdh8y/+GtL&G]RLDR');
define('SECURE_AUTH_SALT', '4jp)WE@{4t61*i8GjZ#N3o?+6kRhX;(<oSa*(`EB2{)QLV$u)mS$&h,MlFH}*#W~');
define('LOGGED_IN_SALT',   ' %8}KoS/DdI2fYNs*vUVdn!+n`);r0y|/*Y}<C;iVo=({5&@N-T~Ti*+:LpAm^er');
define('NONCE_SALT',       'qm.Mh^=L(/lt$+<*0t4z^KNG%GJQ0]#{u[1A6V2YtI3}t+7HThwj(IP*a&4mrW~&');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
